<?php


try{
    $cnx = new PDO('mysql:host=localhost; dbname=uneclepourlesmalloges;charset=utf8', 'root', 'S1mpl0n#C0$Hh$Db');
} catch (PDOException $e) {
    echo 'Echec de la connexion : ' . $e->getMessage();
    exit;
}


?>
