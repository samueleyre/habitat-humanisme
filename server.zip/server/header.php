<?php

header("Access-Control-Allow-Origin: www.uneclepourlesmalloges.com");
header('Access-Control-Allow-Headers: Authorization,Content-Type');
header("Access-Control-Allow-Methods : GET, POST, OPTIONS");



 ?>
